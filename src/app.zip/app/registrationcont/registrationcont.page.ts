import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrationcont',
  templateUrl: './registrationcont.page.html',
  styleUrls: ['./registrationcont.page.scss'],
})
export class RegistrationcontPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

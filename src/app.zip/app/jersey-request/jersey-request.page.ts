import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jersey-request',
  templateUrl: './jersey-request.page.html',
  styleUrls: ['./jersey-request.page.scss'],
})
export class JerseyRequestPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { SwipeDirective } from './swipe.directive';

describe('SwipeDirective', () => {
  it('should create an instance', () => {
    const directive = new SwipeDirective();
    expect(directive).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acknowledgement',
  templateUrl: './acknowledgement.page.html',
  styleUrls: ['./acknowledgement.page.scss'],
})
export class AcknowledgementPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

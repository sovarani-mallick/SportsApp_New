import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-issuance',
  templateUrl: './issuance.page.html',
  styleUrls: ['./issuance.page.scss'],
})
export class IssuancePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

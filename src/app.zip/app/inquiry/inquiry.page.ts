import { Component, OnInit } from '@angular/core';
import { UserService } from '../Services/user.service';

@Component({
  selector: 'app-inquiry',
  templateUrl: './inquiry.page.html',
  styleUrls: ['./inquiry.page.scss'],
})
export class InquiryPage implements OnInit {
  sportsType : any;
  
  constructor(private service:UserService, ) { }
  ngOnInit() {
    console.log('Hello');
    this.service.selectSports().subscribe(res =>{
      console.log(res);
      if(res['status'] == 200){
       this.sportsType = res['Data'];
      }
      console.log('ghgyhg')
      console.log(res['Data'])
     },
     )


     this.service.selectEvents().subscribe(res =>{
      console.log(res);
      if(res['status'] == 200){
       this.sportsType = res['Data'];
      }
     },
     )


     this.service.selectCity().subscribe(res =>{
      console.log(res);
      if(res['status'] == 200){
       this.sportsType = res['Data'];
      }
     },
     )

    }
  
}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-roster',
  templateUrl: './user-roster.page.html',
  styleUrls: ['./user-roster.page.scss'],
})
export class UserRosterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

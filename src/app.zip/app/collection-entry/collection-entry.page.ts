import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collection-entry',
  templateUrl: './collection-entry.page.html',
  styleUrls: ['./collection-entry.page.scss'],
})
export class CollectionEntryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-player-wise-due',
  templateUrl: './player-wise-due.page.html',
  styleUrls: ['./player-wise-due.page.scss'],
})
export class PlayerWiseDuePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

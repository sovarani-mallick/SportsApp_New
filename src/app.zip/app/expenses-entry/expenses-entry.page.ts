import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expenses-entry',
  templateUrl: './expenses-entry.page.html',
  styleUrls: ['./expenses-entry.page.scss'],
})
export class ExpensesEntryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

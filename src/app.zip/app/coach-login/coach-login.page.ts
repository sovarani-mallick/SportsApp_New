import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coach-login',
  templateUrl: './coach-login.page.html',
  styleUrls: ['./coach-login.page.scss'],
})
export class CoachLoginPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

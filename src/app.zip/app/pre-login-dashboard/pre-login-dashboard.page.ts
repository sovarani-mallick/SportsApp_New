import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-login-dashboard',
  templateUrl: './pre-login-dashboard.page.html',
  styleUrls: ['./pre-login-dashboard.page.scss'],
})
export class PreLoginDashboardPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
